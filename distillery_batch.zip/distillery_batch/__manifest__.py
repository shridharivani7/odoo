# -*- coding: utf-8 -*-
{
    'name': "Distillery Batch Creation",

    'summary': """
    
        """,

    'description': """
        Long description of module's purpose
    """,

    'author': "VISHIST Business Solutions Pvt Ltd",
    'website': "http://www.vishistbusinesssolutions.com/",
    'category': 'Batch',
    'version': '0.1',
    # any module necessary for this one to work correctly
    'depends': ['base','mail','product'],

    # always loaded
    'data': [
        'security/groups.xml',
        'security/ir.model.access.csv',
        'views/views.xml',

    ],
    # only loaded in demonstration mode
    'demo': [
       
    ],
}