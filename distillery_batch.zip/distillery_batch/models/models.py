# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import UserError
import pdb
import pdb

class DistilleryBatch(models.Model):
    _name = 'distillery.batch'


    details_of_brand = fields.Char(string="Details of Brand ")
    product_type=fields.Many2one('product.product',string='Product Type')
    no_of_bottles= fields.Char(string="No. of Bottles and Alignment")
    bottle_volume = fields.Char(string="Volume of Bottle")
    date_packing=fields.Date(string="Date of Packing")
    date_expiry=fields.Date(string="Date of Expiry")
    batch_number=fields.Float(string="Batch No.")
    mrp=fields.Float(string="MRP")
