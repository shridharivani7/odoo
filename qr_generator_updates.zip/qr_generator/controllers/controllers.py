# -*- coding: utf-8 -*-
from odoo import http

# class CourtTracking(http.Controller):
#     @http.route('/court_tracking/court_tracking/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/court_tracking/court_tracking/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('court_tracking.listing', {
#             'root': '/court_tracking/court_tracking',
#             'objects': http.request.env['court_tracking.court_tracking'].search([]),
#         })

#     @http.route('/court_tracking/court_tracking/objects/<model("court_tracking.court_tracking"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('court_tracking.object', {
#             'object': obj
#         })