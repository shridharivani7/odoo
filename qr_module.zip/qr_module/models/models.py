# -*- coding: utf-8 -*-

from odoo import models, fields, api
from datetime import datetime
from odoo.exceptions import UserError
import pdb
import pdb
try:
    import qrcode
except ImportError:
    qrcode = None
try:
    import base64
except ImportError:
    base64 = None
from io import BytesIO

"""1.Add Mail thread for every module
   2.Remove unwanted space
   3.Add comments on every function 
   4.Give proper naming for all"""

class GenratorQR(models.Model):
    _name = 'generate.record'
    

   


    no_of_cans = fields.Char(string="Cans")
    no_of_botteles = fields.Char(string="Boxes")
    bottle_line_id = fields.One2many('bottle.line.qr', 'header_id')
    can_line_id = fields.One2many('cans.line.qr', 'cans_header')
    @api.multi
    def generate(self):
        vals={}
        vals1={}
        #pdb.set_trace()

        prefix = str(self.env['ir.config_parameter'].sudo().get_param('qr_module.config.cans_prefix'))
        prefix1 = str(self.env['ir.config_parameter'].sudo().get_param('qr_module.config.bottles_prefix'))
        if prefix=='False':
            raise UserError('Set A Can Prefix In General Settings')
        if prefix1=='False':
            raise UserError('Set A Botteles Prefix In General Settings')
        line_obj=self.env['bottle.line.qr']
        line_obj1 = self.env['cans.line.qr']

        for i in range(int(self.no_of_botteles)+1):
            #pdb.set_trace()
            seq = prefix + self.env['ir.sequence'].next_by_code('bottle.sequence') or '/'
            vals['sequence'] = seq
            vals['header_id']=self.id
            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_L,
                box_size=10,
                border=4,
            )
            qr.add_data(vals['sequence'])
            qr.make(fit=True)

            img = qr.make_image()
            temp = BytesIO()
            img.save(temp, format="PNG")
            qr_image = base64.b64encode(temp.getvalue())
            vals.update({'qr': qr_image,})
            #pdb.set_trace()

            line_obj.create(vals)

        for i in range(int(self.no_of_cans)+1):
            #pdb.set_trace()

            seq = prefix1 + self.env['ir.sequence'].next_by_code('cans.sequence') or '/'
            vals1['sequence'] = seq
            vals1['cans_header'] = self.id
            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_L,
                box_size=10,
                border=4,
            )
            qr.add_data(vals['sequence'])
            qr.make(fit=True)

            img = qr.make_image()
            temp = BytesIO()
            img.save(temp, format="PNG")
            qr_image = base64.b64encode(temp.getvalue())
            vals1.update({'qr': qr_image, })

            line_obj1.create(vals1)
            #pdb.set_trace()
        return True

class BottleQR(models.Model):
    _name = 'bottle.line.qr'

    header_id=fields.Many2one('generate.record')
    sequence = fields.Char(string="QR Sequence",)
    qr = fields.Binary(string="QR Code")

class CansQR(models.Model):
    _name = 'cans.line.qr'

    cans_header=fields.Many2one('generate.record')
    sequence = fields.Char(string="QR Sequence",)
    qr = fields.Binary(string="QR Code")

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    cans_prefix = fields.Char(string="Cans QR Prefix")
    bottles_prefix = fields.Char(string="Bottel QR Prefix")

    def get_values(self):
        res = super(ResConfigSettings, self).get_values()
        cans_prefix = self.env["ir.config_parameter"].get_param("qr_module.config.cans_prefix")
        bottles_prefix = self.env["ir.config_parameter"].get_param("qr_module.config.bottles_prefix")
        res.update({
            'cans_prefix': cans_prefix if type(cans_prefix) else False,
            'bottles_prefix': bottles_prefix if type(bottles_prefix) else False
        }
        )
        return res

    def set_values(self):
        self.env['ir.config_parameter'].sudo().set_param('qr_module.config.cans_prefix', self.cans_prefix)
        self.env['ir.config_parameter'].sudo().set_param('qr_module.config.bottles_prefix', self.bottles_prefix)
