# -*- coding: utf-8 -*-
{
    'name': "QR Genrator",

    'summary': """
    QR Generator for No of Bottles and No of Boxes,
    With Print option 
        """,

    'description': """
        Long description of module's purpose
    """,

    'author': "VISHIST Business Solutions Pvt Ltd",
    'website': "http://www.vishistbusinesssolutions.com/",
    'category': 'QR Generator',
    'version': '0.1',
    # any module necessary for this one to work correctly
    'depends': ['base','mail',],

    # always loaded
    'data': [
        'security/case.xml',
        'security/ir.model.access.csv',
        'views/views.xml',
        'reports/template.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
       
    ],
}