# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import UserError
import pdb
import pdb
import uuid
try:
    import qrcode
except ImportError:
    qrcode = None
try:
    import base64
except ImportError:
    base64 = None
from io import BytesIO

class GenratorQR(models.Model):
    _name = 'generate.record'
    _rec_name='id'


    no_of_boxes = fields.Char(string="Boxes")
    no_of_botteles = fields.Char(string="Bottles")
    bottle_line_id = fields.One2many('bottle.line.qr', 'header_id')
    box_line_id = fields.One2many('box.line.qr', 'box_header')
    @api.multi
    def generate(self):
        bottles={}
        boxes={}
        #pdb.set_trace()
        line_obj=self.env['bottle.line.qr']
        line_obj1 = self.env['box.line.qr']
        prefix = str(self.env['ir.config_parameter'].sudo().get_param('qr_generator.config.cans_prefix'))
        prefix1 = str(self.env['ir.config_parameter'].sudo().get_param('qr_generator.config.bottles_prefix'))
        if prefix == 'False':
            raise UserError('Set A Can Prefix In General Settings')
        if prefix1 == 'False':
            raise UserError('Set A Botteles Prefix In General Settings')
        for i in range(int(self.no_of_botteles)+1):
            #pdb.set_trace()
            seq =uuid.uuid1()
            bottles['sequence'] = prefix1 + self.env['ir.sequence'].next_by_code('bottle.sequence') or '/'
            bottles['header_id']=self.id
            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_L,
                box_size=10,
                border=4,
            )
            qr.add_data(bottles['sequence'])
            qr.make(fit=True)

            img = qr.make_image()
            temp = BytesIO()
            img.save(temp, format="PNG")
            qr_image = base64.b64encode(temp.getvalue())
            bottles.update({'qr': qr_image,})
            #pdb.set_trace()

            line_obj.create(bottles)

        for i in range(int(self.no_of_boxes)+1):
            #pdb.set_trace()

            #seq = uuid.uuid1()
            boxes['sequence'] = prefix + self.env['ir.sequence'].next_by_code('cans.sequence') or '/'
            boxes['box_header'] = self.id
            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_L,
                box_size=10,
                border=4,
            )
            qr.add_data(boxes['sequence'])
            qr.make(fit=True)

            img = qr.make_image()
            temp = BytesIO()
            img.save(temp, format="PNG")
            qr_image = base64.b64encode(temp.getvalue())
            boxes.update({'qr': qr_image, })

            line_obj1.create(boxes)
            #pdb.set_trace()
        return True

class BottleQR(models.Model):
    _name = 'bottle.line.qr'

    header_id=fields.Many2one('generate.record')
    sequence = fields.Char(string="Bottles UUID",)
    qr = fields.Binary(string="Bottles QR Code")

class BoxQR(models.Model):
    _name = 'box.line.qr'

    box_header=fields.Many2one('generate.record')
    sequence = fields.Char(string="Boxes  UUID",)
    qr = fields.Binary(string="Boxes QR Code")

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    cans_prefix = fields.Char(string="Boxes QR Prefix")
    bottles_prefix = fields.Char(string="Bottel QR Prefix")

    def get_values(self):
        res = super(ResConfigSettings, self).get_values()
        cans_prefix = self.env["ir.config_parameter"].get_param("qr_generator.config.cans_prefix")
        bottles_prefix = self.env["ir.config_parameter"].get_param("qr_generator.config.bottles_prefix")
        res.update({
            'cans_prefix': cans_prefix if type(cans_prefix) else False,
            'bottles_prefix': bottles_prefix if type(bottles_prefix) else False
        }
        )
        return res

    def set_values(self):
        self.env['ir.config_parameter'].sudo().set_param('qr_generator.config.cans_prefix', self.cans_prefix)
        self.env['ir.config_parameter'].sudo().set_param('qr_generator.config.bottles_prefix', self.bottles_prefix)